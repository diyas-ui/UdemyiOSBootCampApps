//
//  WeatherModel.swift
//  ByteCoin
//
//  Created by mac on 3/4/21.
//  Copyright © 2021 The App Brewery. All rights reserved.
//

import Foundation


struct WeatherModel {
    var rate: Double
    var currency : String
}
