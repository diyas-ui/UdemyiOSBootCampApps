//
//  DetailViewController.swift
//  Alarm
//
//  Created by mac on 10/15/20.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {


    @IBOutlet weak var pickerAlarm: UIDatePicker!
    
    @IBOutlet weak var textAlarm: UITextField!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func deleteAlarm(_ sender: UIButton) {
        
    }
    
    @IBAction func changeAlarm(_ sender: UIButton) {
        
        
    }
    
    
}
