//
//  ViewController.swift
//  Alarm
//
//  Created by Zhanik on 10/15/20.
//  Copyright © 2020 Zhanik. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource{
    
    var reminder = [Time.init(timeNumber: "15:00", textTime: "Tenis", switchTime: false),
                    Time.init(timeNumber: "17:00", textTime: "Diner", switchTime: true),
                    Time.init(timeNumber: "21:00", textTime: "Sleep", switchTime: false)]
    
    @IBOutlet weak var myTableView: UITableView!
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return reminder.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = (myTableView.dequeueReusableCell(withIdentifier: "myCell" )) as? CustomCell
        cell?.timeLabel.text = reminder[indexPath.row].timeNumber
        cell?.textAlarmLabel.text = reminder[indexPath.row].textTime
        return cell!
    }
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        return .delete
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            tableView.beginUpdates()
            reminder.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
            tableView.endUpdates()
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let detailVC = self.storyboard?.instantiateViewController(withIdentifier: "DetailViewController") as! DetailViewController
        navigationController?.pushViewController(detailVC, animated: true)
        myTableView.deselectRow(at: indexPath, animated: true)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        myTableView.delegate = self
        myTableView.dataSource = self
    }
    
    @IBAction func addReminder(_ sender: UIButton) {
        let saveVC = self.storyboard?.instantiateViewController(withIdentifier: "SaveViewController") as! SaveViewController
        //saveVC.myProtocol = sel
        navigationController?.pushViewController(saveVC, animated: true)
    }
    
    
    
    
    
    
    
    


}

