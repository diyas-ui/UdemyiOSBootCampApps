//
//  SaveViewController.swift
//  Alarm
//
//  Created by mac on 10/15/20.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class SaveViewController: UIViewController, UITextFieldDelegate {
    
    
    
  
    @IBOutlet weak var datePicker: UIDatePicker!
    @IBOutlet weak var alarmLabel: UITextField!


    override func viewDidLoad() {
        super.viewDidLoad()
        alarmLabel.delegate = self
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func saveReminder(_ sender: UIButton) {
        navigationController?.popViewController(animated: true)
    }
    
    
}
