//
//  Time .swift
//  Alarm
//
//  Created by mac on 10/15/20.
//  Copyright © 2020 mac. All rights reserved.
//

import Foundation
import UIKit

class Time{
    var timeNumber: String?
    var textTime: String?
    var switchTime: Bool?
    init(timeNumber: String,textTime: String,switchTime: Bool) {
        self.switchTime = switchTime
        self.textTime = textTime
        self.timeNumber = timeNumber
    }
    
}

